# 【Deepresearch系统】模块六：评估方法

> 基准测试、评估指标与评估流程完整指南

## 目录

```mermaid
%%{init: {"theme": "forest", "flowchart": {"nodeSpacing": 24, "rankSpacing": 34, "padding": 16, "htmlLabels": true, "curve": "basis"}}}%%
flowchart TB
    A["模块六：评估方法"]
    A --> B["1. 评估的核心挑战"]
    A --> C["2. 主流评估基准"]
    A --> D["3. 评估指标"]
    A --> E["4. LLM-as-Judge 评估"]
    A --> F["5. 评估流程"]
    A --> G["6. 评估最佳实践"]
    A --> H["7. 总结"]

    D --> D1["3.1 准确性指标"]
    D --> D2["3.2 报告质量指标（RACE）"]
    D --> D3["3.3 引用质量指标（FACT）"]
    D --> D4["3.4 效率指标"]

    E --> E1["4.1 基本实现"]
    E --> E2["4.2 评估提示模板"]

    F --> F1["5.1 完整评估流水线"]
    F --> F2["5.2 增量评估"]

    G --> G1["6.1 评估配置建议"]
    G --> G2["6.2 评估报告模板"]
    G --> G3["6.3 常见问题处理"]
```

## 1. 评估的核心挑战

### 1.1 为什么 Deep Research 评估困难？

```mermaid
%%{init: {"theme": "forest", "flowchart": {"nodeSpacing": 24, "rankSpacing": 34, "padding": 16, "htmlLabels": true, "curve": "basis"}}}%%
flowchart TB
    A["Deep Research 评估的挑战"]

    A --> B["挑战1：答案多样性"]
    B --> B1["同一事实可能有多种正确表达"]
    B --> B2["示例：法国 GDP 可以写成<br/>3.03 万亿美元 / 约 3 万亿美元 / 3.03 trillion USD"]

    A --> C["挑战2：信息时效性"]
    C --> C1["基准答案可能过时"]
    C --> C2["示例：CEO、政策、市场数据会随时间变化"]

    A --> D["挑战3：部分正确"]
    D --> D1["多答案问题不能只判 0 或 1"]
    D --> D2["示例：诺贝尔奖共同获奖者只答出一人"]

    A --> E["挑战4：开放式问题"]
    E --> E1["没有唯一标准答案"]
    E --> E2["需要评估报告的全面性、深度、准确性、可读性"]
```

挑战示例：

| 挑战 | 问题 | 评估难点 |
|---|---|---|
| 答案多样性 | “法国 GDP 是多少？” | “3.03 万亿美元”“约 3 万亿美元”“2024 年法国 GDP 为 3.03 trillion USD”都可能正确 |
| 信息时效性 | “特斯拉 CEO 是谁？” | 答案可能随时间变化，需要相对稳定事实或定期更新基准 |
| 部分正确 | “列出 2024 年诺贝尔物理学奖得主” | 标准答案是 John Hopfield、Geoffrey Hinton；只答 Geoffrey Hinton 不能简单判 0 或 1 |
| 开放式问题 | “分析 AI 对就业市场的影响” | 没有唯一正确答案，需要评估报告质量 |

### 1.2 评估维度

| 维度 | 描述 | 适用场景 |
|---|---|---|
| 准确性 | 答案是否正确 | 事实问答 |
| 完整性 | 答案是否覆盖所有要点 | 多部分问题 |
| 可靠性 | 多次运行结果是否一致 | 所有场景 |
| 效率 | 完成任务所需步骤/时间 | 生产环境 |
| 报告质量 | 报告的全面性、深度、可读性 | 研究报告生成 |

## 2. 主流评估基准

### 2.1 基准概览

```mermaid
%%{init: {"theme": "forest", "flowchart": {"nodeSpacing": 24, "rankSpacing": 34, "padding": 16, "htmlLabels": true, "curve": "basis"}}}%%
flowchart TB
    A["主流评估基准一览"]

    A --> B["难度：★★★★★★（最难）"]
    B --> B1["BrowseComp（1266题）"]
    B1 --> B11["复杂网页浏览和推理任务"]
    B1 --> B12["需要访问多个网页并综合信息"]
    B1 --> B13["当前最佳：约 50%"]

    A --> C["难度：★★★★★☆"]
    C --> C1["HLE - Humanity's Last Exam（2500题）"]
    C1 --> C11["博士级专家问题"]
    C1 --> C12["跨学科深度知识"]
    C1 --> C13["当前最佳：约 33%"]

    A --> D["难度：★★★★☆☆"]
    D --> D1["GAIA（466题）"]
    D1 --> D11["通用 AI 助手任务"]
    D1 --> D12["多步推理、工具使用"]
    D1 --> D13["分三个级别（L1/L2/L3）"]
    D1 --> D14["当前最佳：约 77%"]

    A --> E["难度：★★★★☆☆"]
    E --> E1["WebWalkerQA（680题）"]
    E1 --> E11["深度网页导航"]
    E1 --> E12["需要多次页面跳转"]
    E1 --> E13["当前最佳：约 75%"]

    A --> F["难度：★★★☆☆☆"]
    F --> F1["FRAMES（824题）"]
    F1 --> F11["多跳检索和综合"]
    F1 --> F12["RAG 能力测试"]
    F1 --> F13["当前最佳：约 80%"]

    A --> G["难度：★★☆☆☆☆"]
    G --> G1["SimpleQA"]
    G1 --> G11["简单事实问答"]
    G1 --> G12["单跳检索"]
    G1 --> G13["当前最佳：约 95%"]

    A --> H["HotpotQA"]
    H --> H1["2跳推理"]
    H --> H2["已被 Deep Research 模型饱和"]
```

### 2.2 各基准详细介绍

#### 2.2.1 BrowseComp

```python
class BrowseCompEvaluator:
    """BrowseComp评估器"""

    def __init__(self, data_path: str):
        self.data = self._load_data(data_path)
        """
        数据格式：
        {
            "id": "bc_001",
            "question": "Find the email of the CTO of the company that developed...",
            "answer": "cto@example.com",
            "difficulty": "hard",
            "required_sources": 3,
            "category": "contact_finding"
        }
        """

    def evaluate(self, model_predictions: List[dict]) -> dict:
        """评估模型预测"""
        results = {
            "total": len(self.data),
            "correct": 0,
            "by_difficulty": {"easy": 0, "medium": 0, "hard": 0},
            "by_category": defaultdict(int)
        }

        for item in self.data:
            pred = self._find_prediction(model_predictions, item["id"])
            if pred and self._is_correct(pred["answer"], item["answer"]):
                results["correct"] += 1
                results["by_difficulty"][item["difficulty"]] += 1
                results["by_category"][item["category"]] += 1

        results["accuracy"] = results["correct"] / results["total"]
        return results

    def _is_correct(self, prediction: str, ground_truth: str) -> bool:
        """判断答案是否正确"""
        pred_normalized = self._normalize(prediction)
        gt_normalized = self._normalize(ground_truth)

        return pred_normalized == gt_normalized or gt_normalized in pred_normalized
```

#### 2.2.2 GAIA

```python
class GAIAEvaluator:
    """GAIA评估器"""

    def __init__(self, data_path: str):
        self.data = self._load_data(data_path)
        """
        数据格式：
        {
            "task_id": "gaia_001",
            "question": "What is the population of...",
            "level": 1,  # 1, 2, or 3
            "answer": "1,234,567",
            "annotator_metadata": {...}
        }
        """

    def evaluate(self, model_predictions: List[dict]) -> dict:
        """评估模型预测"""
        results = {
            "total": len(self.data),
            "correct": 0,
            "by_level": {
                1: {"total": 0, "correct": 0},
                2: {"total": 0, "correct": 0},
                3: {"total": 0, "correct": 0}
            }
        }

        for item in self.data:
            level = item["level"]
            results["by_level"][level]["total"] += 1

            pred = self._find_prediction(model_predictions, item["task_id"])
            if pred and self._gaia_match(pred["answer"], item["answer"]):
                results["correct"] += 1
                results["by_level"][level]["correct"] += 1

        results["accuracy"] = results["correct"] / results["total"]
        for level in [1, 2, 3]:
            level_data = results["by_level"][level]
            level_data["accuracy"] = (
                level_data["correct"] / level_data["total"]
                if level_data["total"] > 0 else 0
            )

        return results

    def _gaia_match(self, prediction: str, ground_truth: str) -> bool:
        """GAIA专用匹配函数"""
        pred_clean = self._clean_answer(prediction)
        gt_clean = self._clean_answer(ground_truth)

        if self._is_numeric(gt_clean):
            return self._numeric_match(pred_clean, gt_clean)

        return pred_clean.lower() == gt_clean.lower()

    def _numeric_match(self, pred: str, gt: str, tolerance: float = 0.01) -> bool:
        """数值匹配，允许1%误差"""
        try:
            pred_num = float(pred.replace(",", ""))
            gt_num = float(gt.replace(",", ""))
            return abs(pred_num - gt_num) / abs(gt_num) < tolerance
        except Exception:
            return False
```

#### 2.2.3 HLE（Humanity's Last Exam）

```python
class HLEEvaluator:
    """HLE评估器"""

    def __init__(self, data_path: str):
        self.data = self._load_data(data_path)
        """
        数据格式：
        {
            "id": "hle_001",
            "question": "In quantum field theory...",
            "answer": "The answer involves...",
            "subject": "physics",
            "difficulty": "expert",
            "requires_calculation": true
        }
        """
        self.judge_model = None  # LLM-as-Judge

    def evaluate(self, model_predictions: List[dict]) -> dict:
        """评估模型预测"""
        results = {
            "total": len(self.data),
            "correct": 0,
            "by_subject": defaultdict(lambda: {"total": 0, "correct": 0})
        }

        for item in self.data:
            subject = item["subject"]
            results["by_subject"][subject]["total"] += 1

            pred = self._find_prediction(model_predictions, item["id"])
            if pred:
                is_correct = self._llm_judge(item["question"], pred["answer"], item["answer"])
                if is_correct:
                    results["correct"] += 1
                    results["by_subject"][subject]["correct"] += 1

        results["accuracy"] = results["correct"] / results["total"]
        return results

    def _llm_judge(self, question: str, prediction: str, ground_truth: str) -> bool:
        """使用LLM判断答案正确性"""
        prompt = f"""你是一位正在批改专家级考试的教授。
请判断学生的答案是否正确。

问题：{question}

标准答案：{ground_truth}

学生答案：{prediction}

评判标准：
1. 核心概念是否正确
2. 关键数值/结论是否准确
3. 允许表达方式不同，但实质内容必须正确

请先分析，然后给出判断（正确/不正确）："""

        response = self.judge_model.generate(prompt)
        return "正确" in response and "不正确" not in response
```

## 3. 评估指标

### 3.1 准确性指标

```python
class AccuracyMetrics:
    """准确性指标计算"""

    @staticmethod
    def pass_at_k(predictions: List[List[bool]], k: int) -> float:
        """
        Pass@k：在k次尝试中至少有一次正确的概率

        predictions: [[True, False, True], [False, False], ...]
                     每个问题的多次预测结果
        """
        total = len(predictions)
        passed = 0

        for pred_list in predictions:
            first_k = pred_list[:k]
            if any(first_k):
                passed += 1

        return passed / total

    @staticmethod
    def consistency_at_k(predictions: List[List[str]], k: int) -> float:
        """
        Cons@k：k次独立尝试的一致性评分

        predictions: [["answer1", "answer1", "answer2"], ...]
        """
        total = len(predictions)
        consistent = 0

        for pred_list in predictions:
            first_k = pred_list[:k]
            normalized = [AccuracyMetrics._normalize(p) for p in first_k]
            if len(set(normalized)) == 1:
                consistent += 1

        return consistent / total

    @staticmethod
    def exact_match(prediction: str, ground_truth: str) -> float:
        """精确匹配"""
        return 1.0 if prediction.strip() == ground_truth.strip() else 0.0

    @staticmethod
    def f1_score(prediction: str, ground_truth: str) -> float:
        """基于词重叠的F1分数"""
        pred_tokens = set(prediction.lower().split())
        gt_tokens = set(ground_truth.lower().split())

        if not pred_tokens or not gt_tokens:
            return 0.0

        common = pred_tokens & gt_tokens
        precision = len(common) / len(pred_tokens)
        recall = len(common) / len(gt_tokens)

        if precision + recall == 0:
            return 0.0

        return 2 * precision * recall / (precision + recall)
```

### 3.2 报告质量指标（RACE）

```python
class ReportQualityMetrics:
    """报告质量指标（RACE Framework）"""

    def __init__(self, judge_model):
        self.judge_model = judge_model

    def evaluate_report(self, question: str, report: str) -> dict:
        """评估研究报告质量"""
        scores = {}

        scores["comprehensiveness"] = self._evaluate_comprehensiveness(question, report)
        scores["insight"] = self._evaluate_insight(question, report)
        scores["instruction_following"] = self._evaluate_instruction_following(question, report)
        scores["readability"] = self._evaluate_readability(report)

        scores["overall"] = (
            0.3 * scores["comprehensiveness"] +
            0.3 * scores["insight"] +
            0.2 * scores["instruction_following"] +
            0.2 * scores["readability"]
        )

        return scores

    def _evaluate_comprehensiveness(self, question: str, report: str) -> float:
        """评估全面性"""
        prompt = f"""评估以下报告对问题的覆盖程度（1-5分）：

问题：{question}

报告：
{report}

评估标准：
1分：严重缺失关键信息
2分：缺少部分重要方面
3分：覆盖主要方面，但不够全面
4分：覆盖全面，少数细节缺失
5分：非常全面，涵盖所有相关方面

请给出评分和简要理由："""

        response = self.judge_model.generate(prompt)
        return self._extract_score(response) / 5.0

    def _evaluate_insight(self, question: str, report: str) -> float:
        """评估洞察深度"""
        prompt = f"""评估以下报告的分析深度（1-5分）：

问题：{question}

报告：
{report}

评估标准：
1分：仅罗列表面信息
2分：有基本分析，但较肤浅
3分：分析有一定深度
4分：深入分析，有见解
5分：非常深入，洞察独到

请给出评分和简要理由："""

        response = self.judge_model.generate(prompt)
        return self._extract_score(response) / 5.0
```

### 3.3 引用质量指标（FACT）

```python
class CitationMetrics:
    """引用质量指标"""

    def evaluate_citations(self, report: str, cited_sources: List[dict]) -> dict:
        """评估引用质量"""
        citations = self._extract_citations(report)

        results = {
            "total_citations": len(citations),
            "valid_citations": 0,
            "accuracy": 0.0,
            "coverage": 0.0
        }

        for citation in citations:
            if self._verify_citation(citation, cited_sources):
                results["valid_citations"] += 1

        if results["total_citations"] > 0:
            results["accuracy"] = results["valid_citations"] / results["total_citations"]

        results["coverage"] = self._evaluate_coverage(citations, cited_sources)
        return results

    def _verify_citation(self, citation: dict, sources: List[dict]) -> bool:
        """验证引用是否准确"""
        cited_url = citation.get("url", "")
        for source in sources:
            if source.get("url") == cited_url:
                return self._content_matches(
                    citation.get("content"),
                    source.get("content")
                )
        return False
```

### 3.4 效率指标

```python
class EfficiencyMetrics:
    """效率指标"""

    @staticmethod
    def action_count(trajectory: List[dict]) -> int:
        """动作数量"""
        return len([t for t in trajectory if t.get("role") == "assistant"])

    @staticmethod
    def tool_call_count(trajectory: List[dict]) -> int:
        """工具调用次数"""
        count = 0
        for t in trajectory:
            if t.get("role") == "assistant":
                if "<tool_call>" in t.get("content", ""):
                    count += 1
        return count

    @staticmethod
    def token_consumption(trajectory: List[dict], tokenizer) -> dict:
        """Token消耗统计"""
        input_tokens = 0
        output_tokens = 0

        for t in trajectory:
            content = t.get("content", "")
            tokens = len(tokenizer.encode(content))

            if t.get("role") == "assistant":
                output_tokens += tokens
            else:
                input_tokens += tokens

        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens
        }

    @staticmethod
    def latency(start_time: float, end_time: float) -> float:
        """延迟时间（秒）"""
        return end_time - start_time
```

## 4. LLM-as-Judge 评估

### 4.1 基本实现

```python
class LLMJudge:
    """LLM作为评判者"""

    def __init__(self, judge_model, config: dict):
        self.model = judge_model
        self.config = config

    def judge_correctness(
        self,
        question: str,
        prediction: str,
        ground_truth: str
    ) -> Tuple[bool, str]:
        """判断答案正确性"""
        prompt = f"""你是一位正在批改测验的老师。
请判断学生的答案是否正确。

问题：{question}

标准答案：{ground_truth}

学生答案：{prediction}

评判指南：
1. 基于事实准确性评判
2. 忽略标点和措辞差异
3. 数值答案允许合理的表达方式差异
4. 如果答案包含标准答案的核心信息，可视为正确

请先逐步分析，然后给出最终判断（正确/不正确）："""

        response = self.model.generate(prompt, temperature=0)
        is_correct = self._parse_judgment(response)
        reasoning = response

        return is_correct, reasoning

    def _parse_judgment(self, response: str) -> bool:
        """解析判断结果"""
        response_lower = response.lower()

        correct_pos = response_lower.rfind("正确")
        incorrect_pos = response_lower.rfind("不正确")

        if incorrect_pos > correct_pos:
            return False
        elif correct_pos > -1:
            return True

        if "incorrect" in response_lower or "wrong" in response_lower:
            return False
        if "correct" in response_lower or "right" in response_lower:
            return True

        return False
```

```python
class ConsensusJudge:
    """多Judge共识评估"""

    def __init__(self, judges: List[LLMJudge]):
        self.judges = judges

    def judge_with_consensus(
        self,
        question: str,
        prediction: str,
        ground_truth: str,
        threshold: float = 0.6
    ) -> Tuple[bool, dict]:
        """使用多个Judge达成共识"""
        votes = []
        reasonings = []

        for judge in self.judges:
            is_correct, reasoning = judge.judge_correctness(
                question, prediction, ground_truth
            )
            votes.append(is_correct)
            reasonings.append(reasoning)

        positive_votes = sum(votes)
        consensus_ratio = positive_votes / len(votes)
        final_judgment = consensus_ratio >= threshold

        return final_judgment, {
            "votes": votes,
            "consensus_ratio": consensus_ratio,
            "reasonings": reasonings
        }
```

### 4.2 评估提示模板

```python
JUDGE_PROMPTS = {
    "factual_qa": """你是一位正在批改测验的老师。
给你一个问题、问题相关的上下文和学生的答案。
根据上下文将学生的答案评为正确或不正确。

问题：{question}
标准答案：{ground_truth}
学生答案：{prediction}

逐步写出你的推理过程以确保结论正确。
仅根据事实准确性评判学生答案。
忽略学生答案与标准答案之间的标点和措辞差异。

判断结果（正确/不正确）：""",

    "numeric_qa": """评估以下数值答案是否正确。

问题：{question}
标准答案：{ground_truth}
学生答案：{prediction}

评判标准：
1. 数值本身是否正确（允许四舍五入）
2. 单位是否正确
3. 允许不同的数值格式（如1000 vs 1,000 vs 1K）

判断结果（正确/不正确）：""",

    "multi_part_qa": """评估以下多部分问题的答案完整性和正确性。

问题：{question}
标准答案：{ground_truth}
学生答案：{prediction}

请分别评估每个部分：
1. 识别问题要求的所有部分
2. 检查每个部分是否被正确回答
3. 给出部分正确的评分（如3/5）

整体判断：""",

    "open_ended": """评估以下开放式问题的回答质量。

问题：{question}
参考答案：{ground_truth}
学生答案：{prediction}

评估维度（每项1-5分）：
1. 相关性：答案是否切题
2. 准确性：信息是否正确
3. 完整性：是否涵盖主要方面
4. 逻辑性：论述是否合理

请给出各维度评分和总体评价："""
}
```

## 5. 评估流程

### 5.1 完整评估流水线

```python
class EvaluationPipeline:
    """完整评估流水线"""

    def __init__(self, config: dict):
        self.config = config
        self.model = config["model"]
        self.tools = config["tools"]
        self.judge = LLMJudge(config["judge_model"], config)

        self.benchmarks = {
            "browsecomp": BrowseCompEvaluator(config["browsecomp_path"]),
            "gaia": GAIAEvaluator(config["gaia_path"]),
            "hle": HLEEvaluator(config["hle_path"])
        }

    def run_full_evaluation(self, num_samples: int = None) -> dict:
        """运行完整评估"""
        results = {}

        for name, evaluator in self.benchmarks.items():
            print(f"评估 {name}...")
            results[name] = self._evaluate_benchmark(evaluator, num_samples)

        results["summary"] = self._generate_summary(results)
        return results

    def _evaluate_benchmark(self, evaluator, num_samples: int) -> dict:
        """评估单个基准"""
        data = evaluator.data
        if num_samples:
            data = data[:num_samples]

        predictions = []
        trajectories = []

        for item in tqdm(data, desc="推理中"):
            result = self._run_inference(item["question"])
            predictions.append({
                "id": item["id"],
                "question": item["question"],
                "answer": result["answer"],
                "ground_truth": item["answer"]
            })
            trajectories.append(result.get("trajectory", []))

        accuracy_result = evaluator.evaluate(predictions)
        efficiency = self._compute_efficiency(trajectories)

        return {
            "accuracy": accuracy_result,
            "efficiency": efficiency,
            "predictions": predictions
        }

    def _run_inference(self, question: str) -> dict:
        """运行推理"""
        inference = IterResearchInference(
            model=self.model,
            tools=self.tools,
            config=self.config["inference_config"]
        )
        return inference.run(question)
```

```python
    def _compute_efficiency(self, trajectories: List[List[dict]]) -> dict:
        """计算效率指标"""
        action_counts = []
        tool_counts = []

        for traj in trajectories:
            action_counts.append(EfficiencyMetrics.action_count(traj))
            tool_counts.append(EfficiencyMetrics.tool_call_count(traj))

        return {
            "avg_actions": np.mean(action_counts),
            "avg_tool_calls": np.mean(tool_counts),
            "std_actions": np.std(action_counts)
        }

    def _generate_summary(self, results: dict) -> dict:
        """生成汇总"""
        summary = {
            "model": self.config.get("model_name", "unknown"),
            "timestamp": datetime.now().isoformat(),
            "benchmarks": {}
        }

        for name, result in results.items():
            if name == "summary":
                continue
            summary["benchmarks"][name] = {
                "accuracy": result["accuracy"]["accuracy"],
                "avg_actions": result["efficiency"]["avg_actions"]
            }

        scores = [
            r["accuracy"]["accuracy"]
            for r in results.values()
            if isinstance(r, dict) and "accuracy" in r
        ]
        summary["overall_accuracy"] = np.mean(scores) if scores else 0
        return summary
```

### 5.2 增量评估

```python
class IncrementalEvaluator:
    """增量评估器（支持断点续评）"""

    def __init__(self, config: dict, checkpoint_dir: str):
        self.config = config
        self.checkpoint_dir = checkpoint_dir

    def evaluate_with_checkpoint(self, benchmark: str, data: List[dict]) -> dict:
        """支持断点续评的评估"""
        checkpoint = self._load_checkpoint(benchmark)
        start_idx = checkpoint.get("last_idx", 0)
        predictions = checkpoint.get("predictions", [])

        try:
            for idx in tqdm(range(start_idx, len(data)), desc="评估中"):
                item = data[idx]
                result = self._run_inference(item["question"])

                predictions.append({
                    "id": item["id"],
                    "answer": result["answer"],
                    "trajectory": result.get("trajectory", [])
                })

                if idx % 10 == 0:
                    self._save_checkpoint(benchmark, idx, predictions)

        except KeyboardInterrupt:
            print("评估中断，保存检查点...")
            self._save_checkpoint(benchmark, idx, predictions)
            raise

        self._save_checkpoint(benchmark, len(data), predictions)
        return {"predictions": predictions}

    def _save_checkpoint(self, benchmark: str, idx: int, predictions: List[dict]):
        """保存检查点"""
        checkpoint = {
            "benchmark": benchmark,
            "last_idx": idx,
            "predictions": predictions,
            "timestamp": datetime.now().isoformat()
        }
        path = os.path.join(self.checkpoint_dir, f"{benchmark}_checkpoint.json")
        with open(path, "w") as f:
            json.dump(checkpoint, f)

    def _load_checkpoint(self, benchmark: str) -> dict:
        """加载检查点"""
        path = os.path.join(self.checkpoint_dir, f"{benchmark}_checkpoint.json")
        if os.path.exists(path):
            with open(path) as f:
                return json.load(f)
        return {}
```

## 6. 评估最佳实践

### 6.1 评估配置建议

```python
evaluation_configs = {
    # 快速验证（开发阶段）
    "quick": {
        "samples_per_benchmark": 50,
        "num_runs": 1,
        "judge_model": "gpt-4o-mini",
        "timeout": 120
    },

    # 标准评估
    "standard": {
        "samples_per_benchmark": None,  # 全量
        "num_runs": 1,
        "judge_model": "gpt-4o",
        "timeout": 300
    },

    # 完整评估（论文报告）
    "full": {
        "samples_per_benchmark": None,
        "num_runs": 3,  # 多次运行取平均
        "judge_model": "gpt-4o",
        "consensus_judges": ["gpt-4o", "claude-3-opus"],
        "timeout": 600
    }
}
```

### 6.2 评估报告模板

```python
def generate_evaluation_report(results: dict) -> str:
    """生成评估报告"""
    report = f"""
# Deep Research Agent 评估报告

## 基本信息
- 模型：{results['summary']['model']}
- 评估时间：{results['summary']['timestamp']}

## 性能概览

| 基准 | 准确率 | 平均动作数 |
|---|---|---|
"""

    for name, data in results["summary"]["benchmarks"].items():
        report += f"| {name} | {data['accuracy']:.1%} | {data['avg_actions']:.1f} |\n"

    report += f"""

## 综合得分
- 整体准确率：{results['summary']['overall_accuracy']:.1%}

## 详细结果
"""

    for name, result in results.items():
        if name == "summary":
            continue
        report += f"### {name}\n"
        report += f"- 准确率：{result['accuracy']['accuracy']:.1%}\n"
        report += f"- 样本数：{result['accuracy']['total']}\n\n"

    return report
```

### 6.3 常见问题处理

| 问题 | 解决方案 |
|---|---|
| 评估结果波动大 | 增加评估次数取平均，使用确定性推理 |
| Judge 不一致 | 使用多 Judge 共识，设置清晰的评判标准 |
| 超时问题 | 设置合理超时，记录超时样本单独分析 |
| 数据泄露 | 确保训练数据不包含测试集 |

## 7. 总结

关键要点：

1. **基准选择**
   - 简单验证：SimpleQA、HotpotQA
   - 标准评估：GAIA、FRAMES
   - 挑战性评估：BrowseComp、HLE

2. **评估指标**
   - 准确性：Pass@k、Exact Match、F1
   - 报告质量：RACE 框架
   - 效率：动作数、Token 消耗

3. **LLM-as-Judge**
   - 使用强模型（GPT-4o、Claude）
   - 设计清晰的评判提示
   - 考虑多 Judge 共识

4. **最佳实践**
   - 支持断点续评
   - 多次运行取平均
   - 详细记录每个样本结果

在下一模块中，我们将介绍工程实践和部署相关内容。
